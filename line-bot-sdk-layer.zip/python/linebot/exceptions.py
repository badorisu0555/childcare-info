# -*- coding: utf-8 -*-

#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.

"""linebot.exceptions module."""

from abc import ABCMeta

from future.utils import with_metaclass

from deprecated import deprecated

from .deprecations import (
    LineBotSdkDeprecatedIn30
)


class BaseError(with_metaclass(ABCMeta, Exception)):
    """Base Exception class."""

    def __init__(self, message='-'):
        """__init__ method.

        :param str message: Human readable message
        """
        self.message = message

    def __repr__(self):
        """repr."""
        return str(self)

    def __str__(self):
        """str.

        :rtype: str
        """
        return '<{0} [{1}]>'.format(
            self.__class__.__name__, self.message)


@deprecated(reason="Use 'from linebot.v3.exceptions import InvalidSignatureError' and v3 webhook handlers instead. See https://github.com/line/line-bot-sdk-python/blob/master/README.rst for more details.", version='3.0.0', category=LineBotSdkDeprecatedIn30)  # noqa: E501
class InvalidSignatureError(BaseError):
    """When Webhook signature does NOT match, this error will be raised."""

    def __init__(self, message='-'):
        """__init__ method.

        :param str message: Human readable message
        """
        super(InvalidSignatureError, self).__init__(message)


class LineBotApiError(BaseError):
    """When LINE Messaging API response error, this error will be raised."""

    def __init__(
            self,
            status_code,
            headers,
            request_id=None,
            accepted_request_id=None,
            error=None
    ):
        """__init__ method.

        :param int status_code: HTTP status code
        :param headers: Response headers
        :type headers: dict[str, str]
        :param str request_id: (optional) Request ID. A unique ID is generated for each request
        :param str accepted_request_id: (optional) The same request has already been accepted
        :param error: (optional) Error class object.
        :type error: :py:class:`linebot.models.error.Error`
        """
        super(LineBotApiError, self).__init__(error.message)

        self.status_code = status_code
        self.headers = headers
        self.request_id = request_id
        self.accepted_request_id = accepted_request_id
        self.error = error

    def __str__(self):
        """str.

        :rtype: str
        """
        if self.accepted_request_id:
            return "{0}: status_code={1}, request_id={2}, " \
                   "accepted_request_id={3}, error_response={4}, headers={5}" \
                .format(self.__class__.__name__,
                        self.status_code,
                        self.request_id,
                        self.accepted_request_id,
                        self.error,
                        self.headers)
        return '{0}: status_code={1}, request_id={2}, error_response={3}, headers={4}'.format(
            self.__class__.__name__, self.status_code, self.request_id, self.error,
            self.headers)
